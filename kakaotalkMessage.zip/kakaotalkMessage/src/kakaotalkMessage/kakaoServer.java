package kakaotalkMessage;
import java.io.*;
import java.net.*;
public class kakaoServer {
	
	    public static void main(String argv[]) throws Exception
	    {
	        ServerSocket listenSocket = new ServerSocket(8080);
	        System.out.println("WebServer Socket Created");
	 
	        Socket connectionSocket;
	        ServerThread serverThread;
	
	        while((connectionSocket = listenSocket.accept()) != null)
	        {
	            serverThread = new ServerThread(connectionSocket);
	            serverThread.start();
	        }
	    }
}
